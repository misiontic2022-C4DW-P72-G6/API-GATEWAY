module.exports = {

    auth_api_url: 'https://userc4dw-db.herokuapp.com',
    account_api_url: 'https://reservasdw-be.herokuapp.com',
    reservas_api_url: 'https://reservasdw-be.herokuapp.com',
    
};
